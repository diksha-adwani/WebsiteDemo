package com.cybage.resourcemanagement.dto;

public class AdminHomeResource {
	
	int empid;
	String ename;
	String designation;
	String billing;
	String startdate;
	String projName;
	String reason;
	
	public AdminHomeResource() {
		super();
	}

	public AdminHomeResource(int empid, String ename, String designation) {
		super();
		this.empid = empid;
		this.ename = ename;
		this.designation = designation;
	}

	public AdminHomeResource(int empid, String projName) {
		super();
		this.empid = empid;
		this.projName = projName;
	}

	public AdminHomeResource(int empid, String ename, String designation, String billing, String startdate) {
		super();
		this.empid = empid;
		this.ename = ename;
		this.designation = designation;
		this.billing = billing;
		this.startdate = startdate;
	}

	public AdminHomeResource(String ename,int empid, String designation, String projName, String reason) {
		super();
		this.empid = empid;
		this.ename = ename;
		this.designation = designation;
		this.projName = projName;
		this.reason = reason;
	}

	public AdminHomeResource(int empid, String ename, String designation, String projName) {
		super();
		this.empid = empid;
		this.ename = ename;
		this.designation = designation;
		this.projName = projName;
	}

	public AdminHomeResource(int empid, String ename, String designation, String billing, String startdate,
			String projName, String reason) {
		super();
		this.empid = empid;
		this.ename = ename;
		this.designation = designation;
		this.billing = billing;
		this.startdate = startdate;
		this.projName = projName;
		this.reason = reason;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getBilling() {
		return billing;
	}

	public void setBilling(String billing) {
		this.billing = billing;
	}

	public String getStartdate() {
		return startdate;
	}

	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}

	public String getProjName() {
		return projName;
	}

	public void setProjName(String projName) {
		this.projName = projName;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	@Override
	public String toString() {
		return "AdminHomeResource [empid=" + empid + ", ename=" + ename + ", designation=" + designation + ", billing="
				+ billing + ", startdate=" + startdate + ", projName=" + projName + ", reason=" + reason + "]";
	}
	
	
	
	
}
