package com.cybage.resourcemanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cybage.resourcemanagement.dao.IAllocationDao;
import com.cybage.resourcemanagement.dao.IEmployeeDao;
import com.cybage.resourcemanagement.dao.IProjectDao;
import com.cybage.resourcemanagement.dto.AdminHome;
import com.cybage.resourcemanagement.dto.AdminHomeResource;
import com.cybage.resourcemanagement.model.Allocation;
import com.cybage.resourcemanagement.model.Employee;
import com.cybage.resourcemanagement.model.ProjectTable;
import com.cybage.resourcemanagement.model.RoleTable;

@Service("employeeService")
@Transactional
public class EmployeeService implements IEmployeeService 
{
	@Autowired
	private IEmployeeDao empDAO;
	@Autowired
	private IProjectDao projectDAO ;
	@Autowired
	private IAllocationDao allocationDAO;
	
	public EmployeeService()
	{
		System.out.println("In Service");
	}

	public Integer getEmployee(String username, String password)
	{
		System.out.println("In Service . . ."+username);
		return empDAO.getEmployee(username,password);
	}


	public Object loginEmployee(String username, String password)
	{
		System.out.println("In Service . . ."+username);
		return empDAO.loginEmployee(username,password);
	}
	
	public Employee searchEmployee(int rollno)
	{
		System.out.println("In List Service");

		return empDAO.searchEmployee(rollno);
	}
	
	public Integer addEmployee(Employee employee)
	{
		System.out.println("In Service . . ."+employee.getDepartment());
		return empDAO.addEmployee(employee);
	}

	public List<Employee> listEmployee() 
	{
		System.out.println("In List Service");

		return empDAO.listEmployee();
	}
	
	public List<ProjectTable> listProjects()
	{
		System.out.println("In Admin List Project Service");

		return empDAO.listProjects();
	}
	
	public List<ProjectTable> listManagerProjects(Integer empid)
	{
		System.out.println("In Manager List Project Service");

		return empDAO.listManagerProjects(empid);
	}
	
	public List<RoleTable> listRoles() 
	{
		System.out.println("In List Service");

		return empDAO.listRoles();
	}
	

	public List<AdminHomeResource> SearchProjectId(String proj_name,String role)
	{
		System.out.println("In  SearchProjectId Service");
		return empDAO.SearchProjectId(proj_name,role);
	}

	public Employee searchEmployee(Integer rollno) {
		// TODO Auto-generated method stub
		return null;
	}
	
public Employee FetchResource(int empid) {
		
		return empDAO.FetchResource(empid);
	}

	
	public void AllocateResourceToProject(int empid, String proj_name)
	{
		Allocation allocation = new Allocation();
		ProjectTable proj = projectDAO.getProjectByName(proj_name);
		Employee emp = empDAO.FetchResource(empid);
		allocation.setEmployee(emp);
		allocation.setProjectTable(proj);
		allocation.setStatus(0);
		int allocationId = allocationDAO.save(allocation);
		System.out.println(allocationId);
	}

	public void UnfitAllocateResource(String reason, int empid, String projectName) {
		
		Allocation allocation = allocationDAO.getAllocationByProjNameEmpId(projectName, empid);
		
		ProjectTable proj = projectDAO.getProjectByName(projectName);
		Employee emp = empDAO.FetchResource(empid);
		allocation.setEmployee(emp);
		allocation.setProjectTable(proj);
		allocation.setStatus(1);
		allocation.setReason(reason);
		allocationDAO.update(allocation);
	
		
	}

	public List<AdminHome> SearchProjectsByEmpId(int empid)
	{
		System.out.println("In Employee service");
		List<AdminHome> proj = (List<AdminHome>) projectDAO.getProjectByEmpId(empid);
		return proj;
	}

	public List<AdminHomeResource> SearchPendingApproval(String projName)
	{
		System.out.println("In service");
		List<AdminHomeResource> employeelist = empDAO.getEmployeeByProjName(projName);
		return employeelist;
	}

	public List<AdminHomeResource> GetEmployeePendingApproval()
	{
		System.out.println("In service");
		List<AdminHomeResource> employeelist = empDAO.GetEmployeePendingApproval();
		return employeelist;
	}

	public List<AdminHomeResource> GetEmployeeRejectByManager() {
		System.out.println("In service");
		List<AdminHomeResource> employeelist = empDAO.GetEmployeeRejectByManager();
		return employeelist;
	}

	public void releaseResource(Integer empid,String projName)
	{
		empDAO.releaseResource(empid,projName);
	}
	
}
