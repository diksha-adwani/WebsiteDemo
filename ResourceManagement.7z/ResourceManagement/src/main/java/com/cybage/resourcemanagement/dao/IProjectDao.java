package com.cybage.resourcemanagement.dao;

import java.util.List;

import com.cybage.resourcemanagement.dto.AdminHome;
import com.cybage.resourcemanagement.model.ProjectTable;

public interface IProjectDao {

	public ProjectTable getProjectByName(String projName);

	public List<AdminHome> getProjectByEmpId(int empid);

	
		
}
