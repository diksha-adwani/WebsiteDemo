package com.cybage.resourcemanagement.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cybage.resourcemanagement.dto.AdminHome;
import com.cybage.resourcemanagement.model.ProjectTable;

@Repository
public class ProjectDao implements IProjectDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public ProjectTable getProjectByName(String projName)
	{
		Session session =  sessionFactory.getCurrentSession();
		ProjectTable proj1=(ProjectTable)session.createQuery
				(" from ProjectTable p where p.proj_name=:projName ")
                .setParameter("projName", projName)
                .uniqueResult();

		return proj1;
	}

	public List<AdminHome> getProjectByEmpId(int empid)
	{
		System.out.println("In Project DAO");
		Session session =  sessionFactory.getCurrentSession();
		List<AdminHome> projectlist=session.createQuery
				(" select new com.cybage.resourcemanagement.dto.AdminHome(RPT.projectTable.proj_name)"
						+ " from ResourceProjectTable RPT where RPT.employee.empid =:empid ")
                .setParameter("empid", empid)
                .list();
		
		System.out.println(projectlist);
		return projectlist;
	}

	
	
}
