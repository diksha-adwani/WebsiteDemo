package com.cybage.resourcemanagement.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cybage.resourcemanagement.model.Allocation;

@Repository
public class AllocationDao implements IAllocationDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public Integer save(Allocation allocation) {
		
        Session session=sessionFactory.getCurrentSession();
        System.out.println(allocation.getProjectTable());
        Integer allocationId=(Integer)session.save(allocation);
        System.out.println(allocationId);
        return allocationId;

	}

public Allocation getAllocationByProjNameEmpId(String proj_name,int empid) {
		
        Session session=sessionFactory.getCurrentSession();
       Allocation allocation=(Allocation) session.createQuery
    		   				("from Allocation a where a.projectTable.proj_name=:proj_name and a.employee.empid=:empid" )
    		   				.setParameter("proj_name", proj_name)
    		   				.setParameter("empid", empid)
    		   				.uniqueResult();
       
       System.out.println(allocation);
        return allocation;

	}
	

	public void update(Allocation allocation) {
			Session session=sessionFactory.getCurrentSession();
	        System.out.println(allocation.getProjectTable());
	        session.update(allocation);
	
	}

}
