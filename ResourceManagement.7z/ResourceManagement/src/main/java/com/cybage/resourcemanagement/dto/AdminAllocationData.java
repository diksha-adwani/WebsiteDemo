package com.cybage.resourcemanagement.dto;

public class AdminAllocationData {

	int empid;
	String projectName;
	String reason;
	String role;
	float billing;
	String startdate;
	String enddate;
	public AdminAllocationData() {
		super();
	}
	public AdminAllocationData(int empid, String projectName, String reason, String role, float billing,
			String startdate, String enddate) {
		super();
		this.empid = empid;
		this.projectName = projectName;
		this.reason = reason;
		this.role = role;
		this.billing = billing;
		this.startdate = startdate;
		this.enddate = enddate;
	}
	
	
	
	public AdminAllocationData(int empid, String projectName) {
		super();
		this.empid = empid;
		this.projectName = projectName;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public float getBilling() {
		return billing;
	}
	public void setBilling(float billing) {
		this.billing = billing;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getEnddate() {
		return enddate;
	}
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
	@Override
	public String toString() {
		return "AdminAllocationData [empid=" + empid + ", projectName=" + projectName + ", reason=" + reason + ", role="
				+ role + ", billing=" + billing + ", startdate=" + startdate + ", enddate=" + enddate + "]";
	}
	
	
	
	
}
