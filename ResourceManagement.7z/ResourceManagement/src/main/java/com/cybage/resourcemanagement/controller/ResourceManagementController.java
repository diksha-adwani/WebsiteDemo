package com.cybage.resourcemanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.cybage.resourcemanagement.dto.AdminAllocationData;
import com.cybage.resourcemanagement.dto.AdminHome;
import com.cybage.resourcemanagement.dto.AdminHomeResource;
import com.cybage.resourcemanagement.model.Employee;
import com.cybage.resourcemanagement.model.ProjectTable;
import com.cybage.resourcemanagement.model.RoleTable;
import com.cybage.resourcemanagement.service.IEmployeeService;



@RestController
public class ResourceManagementController 
{
	Employee emp;
	String username;
	String password;
	Integer resourceId;
	Integer unfitId;
	String unfitproj;
	@Autowired
	IEmployeeService employeeService;


	@RequestMapping(value = "/employees/", method = RequestMethod.GET)
	public ResponseEntity<List<Employee>> listAllUsers() 
	{
		System.out.println("In List Resource Controller . . . ");
		List<Employee> users = employeeService.listEmployee();

		return new ResponseEntity<List<Employee>>(users, HttpStatus.OK);
	}

	@RequestMapping(value = "/projects/", method = RequestMethod.GET)
	public ResponseEntity<List<ProjectTable>> listAllProjects() 
	{
		System.out.println("In List Resource Controller . . . ");
		List<ProjectTable> projects = employeeService.listProjects();

		return new ResponseEntity<List<ProjectTable>>(projects, HttpStatus.OK);
	}

	@RequestMapping(value = "/roles/", method = RequestMethod.GET)
	public ResponseEntity<List<RoleTable>> listAllRoles() 
	{
		System.out.println("In List Resource Controller . . . ");
		List<RoleTable> projects = employeeService.listRoles();

		return new ResponseEntity<List<RoleTable>>(projects, HttpStatus.OK);
	}

	@RequestMapping(value = "/login/", method = RequestMethod.POST)
	public ResponseEntity<Void> loginEmployee(@RequestBody Employee employee, UriComponentsBuilder ucBuilder) 
	{
		System.out.println("In login Resource Controller . . . "+employee.getUsername()+""+employee.getPassword());

		username = employee.getUsername();
		password = employee.getPassword();

		emp  = (Employee) employeeService.loginEmployee(username, password);

		System.out.println("Employee Id : ---------------------"+emp);

		HttpHeaders headers = new HttpHeaders();

		return new ResponseEntity<Void> (headers, HttpStatus.OK);
	}

	@RequestMapping(value = "/loginSuccess/", method = RequestMethod.GET)
	public ResponseEntity<Employee> loginSuccess() 
	{
		return new ResponseEntity<Employee> (emp, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/loginManagerSuccess/", method = RequestMethod.GET)
	public ResponseEntity<List<ProjectTable>> loginManagerSuccess() 
	{
		System.out.println("In List Resource Controller . . . ");
		List<ProjectTable> projects = employeeService.listManagerProjects(emp.getEmpid());

		return new ResponseEntity<List<ProjectTable>>(projects, HttpStatus.OK);	}

	

	@RequestMapping(value = "/SearchProjectId/", method = RequestMethod.POST)
	public  ResponseEntity<List<AdminHomeResource>> SearchProjectId(@RequestBody AdminHome adminhome, UriComponentsBuilder ucBuilder) 
	{
		System.out.println("In controller");
		//System.out.println(adminhome.getProj_name());
		//System.out.println(adminhome.getRole());
		
		String proj_name = adminhome.getProj_name();
		String role = adminhome.getRole();
				
		List<AdminHomeResource> project_resource = employeeService.SearchProjectId(proj_name,role);
				
		return  new ResponseEntity<List<AdminHomeResource>>(project_resource, HttpStatus.OK);
			
	}
	
	
	
	@RequestMapping(value = "/AllocateResourceToProject/", method = RequestMethod.POST)
	public  ResponseEntity<Void> AllocateResourceToProject(@RequestBody  AdminAllocationData adminallocate, UriComponentsBuilder ucBuilder) 
	{
		System.out.println("In controller");
		System.out.println(adminallocate.getEmpid());
		System.out.println(adminallocate.getProjectName());
		employeeService.AllocateResourceToProject(adminallocate.getEmpid(),adminallocate.getProjectName());
		
		HttpHeaders headers = new HttpHeaders();
		return new ResponseEntity<Void> (headers, HttpStatus.OK);
	}	

	@RequestMapping(value = "/GetEmployeeToUnfit/", method = RequestMethod.POST)
	public  ResponseEntity<Employee> GetEmployeeToUnfit(@RequestBody  Employee employee, UriComponentsBuilder ucBuilder) 
	{
		System.out.println("In controller");
	//	System.out.println(employee.getEmpid());
		
		Employee emp1 = employeeService.FetchResource(employee.getEmpid());
		System.out.println(emp1.getEmpid());
		System.out.println(emp1.getEname());
		System.out.println(emp1.getDesigination());
		System.out.println(emp1.getDepartment());
		
		return  new ResponseEntity<Employee>(emp1, HttpStatus.OK);
	}
	
	
	
	@RequestMapping(value = "/FitAllocateResource/", method = RequestMethod.POST)
	public  ResponseEntity<Void> FitAllocateResource(@RequestBody  AdminAllocationData allocateunfit, UriComponentsBuilder ucBuilder) 
	{
		System.out.println("In controller");
		System.out.println(allocateunfit.getEmpid());
		System.out.println(allocateunfit.getProjectName());
		System.out.println(allocateunfit.getBilling());
		System.out.println(allocateunfit.getRole());
		System.out.println(allocateunfit.getStartdate());
		System.out.println(allocateunfit.getEnddate());
		employeeService.UnfitAllocateResource(allocateunfit.getReason(),allocateunfit.getEmpid(),allocateunfit.getProjectName());
		
		HttpHeaders headers = new HttpHeaders();
		return new ResponseEntity<Void> (headers, HttpStatus.OK);
	}	
	
	
	@RequestMapping(value = "/fetchProjectOfManager/", method = RequestMethod.POST)
	public  ResponseEntity<List<AdminHome>> fetchProjectOfManager(@RequestBody  Employee employee, UriComponentsBuilder ucBuilder) 
	{
		System.out.println("In controller");
		System.out.println(employee.getEmpid());
		
		List<AdminHome> proj = employeeService.SearchProjectsByEmpId(employee.getEmpid());

		System.out.println(proj);
		return  new ResponseEntity<List<AdminHome>>(proj, HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/SearchPendingApproval/", method = RequestMethod.POST)
	public  ResponseEntity<List<AdminHomeResource>> SearchPendingApproval(@RequestBody AdminHome adminhome, UriComponentsBuilder ucBuilder) 
	{
		
		System.out.println(adminhome.getProj_name());
			
		List<AdminHomeResource> employeelist = employeeService.SearchPendingApproval(adminhome.getProj_name());

		return  new ResponseEntity<List<AdminHomeResource>>(employeelist, HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/GetEmployeePendingApproval/", method = RequestMethod.GET)
	public  ResponseEntity<List<AdminHomeResource>> GetEmployeePendingApproval() 
	{
		System.out.println("In controller");
		List<AdminHomeResource> employeelist = employeeService.GetEmployeePendingApproval();
		System.out.println(employeelist);
		return  new ResponseEntity<List<AdminHomeResource>>(employeelist, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/GetEmployeeRejectByManager/", method = RequestMethod.GET)
	public  ResponseEntity<List<AdminHomeResource>> GetEmployeeRejectByManager() 
	{
		System.out.println("In controller");
		List<AdminHomeResource> employeelist = employeeService.GetEmployeeRejectByManager();
		System.out.println(employeelist);
		return  new ResponseEntity<List<AdminHomeResource>>(employeelist, HttpStatus.OK);
	}

	@RequestMapping(value = "/receiveEmpId/", method = RequestMethod.POST)
	public ResponseEntity<Void> receiveEmpId(@RequestBody Integer empid, UriComponentsBuilder ucBuilder) 
	{
		resourceId = empid;
		HttpHeaders headers = new HttpHeaders();
		return new ResponseEntity<Void> (headers, HttpStatus.OK);
	}
	
	
	
	
	@RequestMapping(value = "/fetchResourceToAllocate/", method = RequestMethod.GET)
	public  ResponseEntity<Employee> fetchResourceToAllocate() 
	{
		Employee emp1 = employeeService.FetchResource(resourceId);
		
		return  new ResponseEntity<Employee>(emp1, HttpStatus.OK);
				
	}	
	
	
	@RequestMapping(value = "/receiveEmpIdprojid/", method = RequestMethod.POST)
	public ResponseEntity<Void> receiveEmpIdprojid(@RequestBody AdminAllocationData admin, UriComponentsBuilder ucBuilder) 
	{
		unfitId = admin.getEmpid();
		unfitproj=admin.getProjectName();
		HttpHeaders headers = new HttpHeaders();
		return new ResponseEntity<Void> (headers, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getEmployeeToUnfit/", method = RequestMethod.GET)
	public  ResponseEntity<Employee> unFitResource() 
	{
		System.out.println("In controller Satyam"+resourceId);
	//	System.out.println(employee.getEmpid());
		
		Employee emp1 = employeeService.FetchResource(unfitId);

		return  new ResponseEntity<Employee>(emp1, HttpStatus.OK);
				
	}	
	
	@RequestMapping(value = "/UnfitAllocateResource/", method = RequestMethod.POST)
	public  ResponseEntity<Void> UnfitAllocateResource(@RequestBody  AdminAllocationData allocateunfit, UriComponentsBuilder ucBuilder) 
	{
		System.out.println("In controller");
		System.out.println(allocateunfit.getReason());
	//	System.out.println(allocateunfit.getEmpid());
		//System.out.println(allocateunfit.getProjectName());
		employeeService.UnfitAllocateResource(allocateunfit.getReason(),unfitId,unfitproj);
		
		HttpHeaders headers = new HttpHeaders();
		return new ResponseEntity<Void> (headers, HttpStatus.OK);
	}	
	
	
	@RequestMapping(value = "/releaseEmployee/", method = RequestMethod.POST)
	public ResponseEntity<Void> releaseEmployee(@RequestBody AdminHomeResource admin, UriComponentsBuilder ucBuilder) 
	{
		System.out.println("In Manager login Resource Controller Aa Gaya Mahesh. . . "+admin.getEmpid()+""+admin.getProjName());
		employeeService.releaseResource(admin.getEmpid(),admin.getProjName());
		HttpHeaders headers = new HttpHeaders();
		return new ResponseEntity<Void> (headers, HttpStatus.OK);
	}



}