package com.cybage.resourcemanagement.service;

import java.util.List;

import com.cybage.resourcemanagement.dto.AdminHome;
import com.cybage.resourcemanagement.dto.AdminHomeResource;
import com.cybage.resourcemanagement.model.Employee;
import com.cybage.resourcemanagement.model.ProjectTable;
import com.cybage.resourcemanagement.model.RoleTable;



public interface IEmployeeService 
{
	public Integer getEmployee(String username, String password);
	
	public Object loginEmployee(String username, String password);
	
	public Integer addEmployee(Employee employee);
	
	public List<Employee> listEmployee();	
	
	public Employee searchEmployee(Integer rollno);
	
	public List<ProjectTable> listProjects() ;
	
	public List<ProjectTable> listManagerProjects(Integer empid);
	
	public List<RoleTable> listRoles() ;
	
	public List<AdminHomeResource> SearchProjectId(String proj_name,String role);
	
	public Employee FetchResource(int empid);

	public void AllocateResourceToProject(int empid, String projectName);
	
	public void UnfitAllocateResource(String reason, int empid, String projectName);

	public List<AdminHome> SearchProjectsByEmpId(int empid);

	public List<AdminHomeResource> SearchPendingApproval(String proj_name);

	public List<AdminHomeResource> GetEmployeePendingApproval();

	public List<AdminHomeResource> GetEmployeeRejectByManager();
	
	public void releaseResource(Integer empid,String projName);
}
