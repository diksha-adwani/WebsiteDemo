package com.cybage.resourcemanagement.dao;

import com.cybage.resourcemanagement.model.Allocation;

public interface IAllocationDao {

	public Integer save(Allocation allocation);

	public Allocation getAllocationByProjNameEmpId(String proj_name,int empid);
	
	public void update(Allocation allocation);
}
