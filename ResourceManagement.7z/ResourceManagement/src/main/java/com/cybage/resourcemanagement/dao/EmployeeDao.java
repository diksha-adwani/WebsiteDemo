package com.cybage.resourcemanagement.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cybage.resourcemanagement.dto.AdminHome;
import com.cybage.resourcemanagement.dto.AdminHomeResource;
import com.cybage.resourcemanagement.model.Employee;
import com.cybage.resourcemanagement.model.ProjectTable;
import com.cybage.resourcemanagement.model.RoleTable;


@Repository("empDAO")
public class EmployeeDao implements IEmployeeDao 
{
	@Autowired
	private SessionFactory sessionFactory;
	
	private Session	session;
	
	public EmployeeDao()
	{
		System.out.println("In Dao Default constr . . .");
	}

	public Integer getEmployee(String username, String password) 
	{
		session =  sessionFactory.getCurrentSession();
		System.out.println(username+""+password);
		String hql = "from employee where employee.username = 'username' and employee.password = 'password'";
		Query query = session.createQuery(hql);
		int id = query.executeUpdate();
		System.out.println("Record Updated : "+id);
		return id;
	}
	
	public Object loginEmployee(String username, String password) 
	{
		session =  sessionFactory.getCurrentSession();
		System.out.println(username+"\n"+password);
		String hql = "from Employee where username =:username and password =:password";
		Query query = session.createQuery(hql);
		query.setParameter("username", username);
		query.setParameter("password", password);
		Employee emp = (Employee) query.uniqueResult();
		if(emp == null)
			return 0;
		
		String hql1 = "from Employee where username =:username and password =:password and desigination=:desigination";
		Query query1 = session.createQuery(hql1);
		query1.setParameter("username", username);
		query1.setParameter("password", password);
		
		if(emp.getDesigination().equals("manager")||emp.getDesigination().equals("admin"))
		{
			query1.setParameter("desigination",emp.getDesigination());
			return emp;
		}
		
		String hql2 = "select RPT.projectTable.proj_id,RPT.projectTable.proj_name from ResourceProjectTable RPT where RPT.employee.empid =:id";	  
		Query query2 = session.createQuery(hql2);
		query2.setParameter("id", emp.getEmpid());
		
        List<Object> objs = (List<Object>)query2.list();
        for (Object obj : objs) {
            Object[] o = (Object[]) obj;
            String proj_id =  String.valueOf(o[0]);
            String proj_name =  String.valueOf(o[1]);
            System.out.println(proj_id +"   " + proj_name );
        }
        
    	return null;
	}
	
	public Employee searchEmployee(Integer rollno)
	{
		 session = sessionFactory.getCurrentSession();
		
		 Employee s = (Employee) session.get(Employee.class, rollno);
		 return s;
	}
	
	public Integer addEmployee(Employee employee) 
	{
		Integer id = (Integer) sessionFactory.getCurrentSession().save(employee);
		System.out.println("Object Saved");
		return id;	
	}
	
	public List<Employee> listEmployee() 
	{
		 session = sessionFactory.getCurrentSession();
		
		List<Employee> personsList = session.createQuery("from Employee").list();
		
		return personsList;
	}
	
	public List<ProjectTable> listProjects() 
	{
		session = sessionFactory.getCurrentSession();
		
		List<ProjectTable> projectLlist = session.createQuery("from ProjectTable").list();
		
		return projectLlist;
	}
	
	public List<ProjectTable> listManagerProjects(Integer empid)
	{
		System.out.println("In Project DAO");
		session = sessionFactory.getCurrentSession();
		
		System.out.println("In Dao Id : ----------->"+empid);
		List<ProjectTable> projectlist=session.createQuery
				(" select new com.cybage.resourcemanagement.model.ProjectTable(RPT.projectTable.proj_name)"
						+ " from ResourceProjectTable RPT where RPT.employee.empid =:empid ")
                .setParameter("empid", empid)
                .list();
		return projectlist;
	}
	
	public List<RoleTable> listRoles() 
	{
		 session = sessionFactory.getCurrentSession();
		
		List<RoleTable> roleList = session.createQuery("from RoleTable").list();
		
		return roleList;
	}

	

public List<AdminHomeResource> SearchProjectId(String proj_name,String role) {
		
		session =  sessionFactory.getCurrentSession();
		System.out.println("In DAO Layer");
		String hql = "from ProjectTable where proj_name =:proj_name";
		Query query = session.createQuery(hql);
		query.setParameter("proj_name", proj_name);
		ProjectTable proj = (ProjectTable) query.uniqueResult();
		System.out.println(proj.getProj_id());
		String hql1 = "select e.empid,e.ename,e.desigination,rp.billing,"
                + "rp.start_date from ResourceProjectTable rp inner join "
                + "rp.employee e inner join rp.projectTable p, "
                + "RoleTable rtbl where p.proj_name=:projName and "
                + "rtbl.role=:role and rtbl.employee.empid=e.empid ";
       
	
		Query query1 = session.createQuery(hql1);
		 query1.setParameter("projName",proj_name) 
	        .setParameter("role",role );
		// query1.setParameter("id", proj.getProj_id());
        List<Object[]> objs = query1.list();
       
        List<AdminHomeResource> adminresourcelist= new ArrayList<AdminHomeResource>();
        
        for (Object[] aRow : objs) {
           adminresourcelist.add(new AdminHomeResource(Integer.parseInt(String.valueOf(aRow[0])),String.valueOf(aRow[1]),String.valueOf(aRow[2]),String.valueOf(aRow[3]),String.valueOf(aRow[4])));
        }
		return adminresourcelist;
		
	//	return proj.getProj_id();
	
	}
	
	public Employee FetchResource(Integer empid) 
	{
		session =  sessionFactory.getCurrentSession();
		System.out.println("In DAO Layer");
		System.out.println(empid);
		String hql = "from Employee where empid=:empid";	  
		Query query = session.createQuery(hql);
		query.setParameter("empid", empid);
		Employee emp =(Employee) query.uniqueResult();
		
		return emp;
	}



	public List<AdminHomeResource> getEmployeeByProjName(String proj_name) {
		
		System.out.println("In Employee DAO");
		Session session =  sessionFactory.getCurrentSession();
		List<AdminHomeResource> employeelist=session.createQuery
				(" select new com.cybage.resourcemanagement.dto.AdminHomeResource(alloc.employee.empid,alloc.employee.ename,alloc.employee.desigination)"
						+ " from Allocation alloc where alloc.projectTable.proj_name =:proj_name and alloc.status=:status")
                .setParameter("proj_name", proj_name)
                .setParameter("status", 0)
                .list();
		
		System.out.println(employeelist);
		return employeelist;
	}

	public List<AdminHomeResource> GetEmployeePendingApproval() 
	{
		System.out.println("In Employee DAO");
		Session session =  sessionFactory.getCurrentSession();
		List<AdminHomeResource> employeelist=session.createQuery
				(" select new com.cybage.resourcemanagement.dto.AdminHomeResource(alloc.employee.empid,alloc.employee.ename,alloc.employee.desigination,alloc.projectTable.proj_name)"
						+ " from Allocation alloc where alloc.status=:status")
                .setParameter("status",0)
                .list();
		
		System.out.println(employeelist);
		return employeelist;
	}

	public List<AdminHomeResource> GetEmployeeRejectByManager() 
	{
		System.out.println("In Employee DAO");
		Session session =  sessionFactory.getCurrentSession();
		List<AdminHomeResource> employeelist=session.createQuery
				(" select new com.cybage.resourcemanagement.dto.AdminHomeResource(alloc.employee.ename,alloc.employee.empid,alloc.employee.desigination,alloc.projectTable.proj_name,alloc.reason)"
						+ " from Allocation alloc where alloc.status=:status")
                .setParameter("status", 1)
                .list();
		
		System.out.println(employeelist);
		return employeelist;
	}
	
	public void releaseResource(Integer empid,String projName)
	{
		Session session =  sessionFactory.getCurrentSession();
		
		String hql2 = "select proj_id from ProjectTable where proj_name=:proj_name";	  
		Query query2 = session.createQuery(hql2);
		query2.setParameter("proj_name",projName);
		int proj_id = (Integer) query2.uniqueResult();
		
		
		
		
		Query query=session.createQuery("update ResourceProjectTable RPT set RPT.projectTable.proj_id=:id where RPT.employee.empid=:empid and RPT.projectTable.proj_id=:proj_id")
				.setParameter("id", 100).setParameter("empid", empid).setParameter("proj_id", proj_id);
		
		query.executeUpdate();
		
		System.out.println("Welcome"+query.executeUpdate());	
	}

	
}
